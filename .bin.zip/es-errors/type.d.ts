declare const TypeError: TypeErrorConstructor

export = TypeError;
